import React from "react";
import "./CuntomerSidebar.css";

function CuntomerSidebar() {
  return <div className="cus-slidebar-container">CuntomerSidebar</div>;
}

export default CuntomerSidebar;

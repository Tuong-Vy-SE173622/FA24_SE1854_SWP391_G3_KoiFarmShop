export const API_URL = "https://localhost:7226";

import React from "react";

function AccountPage() {
  return <div>AccountPage</div>;
}

export default AccountPage;

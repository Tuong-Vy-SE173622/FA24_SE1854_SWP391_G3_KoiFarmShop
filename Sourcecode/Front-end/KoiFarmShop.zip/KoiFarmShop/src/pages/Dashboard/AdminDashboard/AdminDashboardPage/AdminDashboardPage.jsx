import React from "react";

function AdminDashboardPage() {
  return <div>AdminDashboardPage</div>;
}

export default AdminDashboardPage;

import React from "react";

function KoiPage() {
  return <div>KoiPage</div>;
}

export default KoiPage;

import React from "react";
import "./KoiDetailPage.css";

function KoiDetailPage() {
  return (
    <div
      style={{
        // backgroundColor: "lightblue",
        // height: "90vh",
        marginTop: "100px",
      }}
    >
      KoiDetailPage
    </div>
  );
}

export default KoiDetailPage;
